# Ragam Batik App

Selamat datang di Ragam Batik App. Temukan Keindahan Dan Filosofi Di Balik Setiap Motif Batik Indonesia.
Ikuti panduan di bawah ini untuk menginstal dan menjalankan aplikasi untuk mulai perjalananmu.

## Prasyarat

Sebelum memulai, pastikan Anda telah menginstal perangkat lunak berikut di komputer Anda:

  * [Node.js](https://nodejs.org/) (yang akan menyertakan `npm`)
  * Code Editor pilihan Anda (misalnya [Visual Studio Code](https://code.visualstudio.com/))
  * Web Browser (misalnya Chrome, Firefox, atau lainnya)

## Instalasi

Ikuti langkah-langkah berikut untuk menyiapkan dan menjalankan proyek di lingkungan lokal Anda.

1.  **Download File Proyek**
    Unduh file proyek dalam format ZIP dengan nama `Ragam-Batik-App.zip`.

2.  **Ekstrak File**
    Ekstrak konten dari file `Ragam-Batik-App.zip` ke direktori atau folder pilihan Anda.

3.  **Buka di Code Editor**
    Buka folder proyek yang telah diekstrak menggunakan code editor seperti Visual Studio Code.

4.  **Buka Terminal**
    Buka terminal terintegrasi di dalam code editor Anda. Di VS Code, Anda bisa membukanya melalui menu `Terminal` \> `New Terminal` atau dengan shortcut \`Ctrl+\`\`.

5.  **Install Dependencies**
    Jalankan perintah berikut di terminal untuk menginstal semua paket yang dibutuhkan oleh proyek:

    npm install

6.  **Build Aplikasi**
    Setelah instalasi selesai, jalankan perintah berikut untuk membangun (build) aplikasi:
 
    npm run build

7.  **Selesai**
    Sekarang aplikasi siap untuk dijalankan. Anda dapat melanjutkan ke langkah berikutnya untuk membuat akun.

## Membuat Akun & Login

Untuk dapat mengakses fitur lengkap dari aplikasi, Anda perlu membuat akun terlebih dahulu.

1.  **Pilih Menu Signup**
    Pada halaman utama aplikasi, cari dan klik tombol atau link **"Signup"** yang biasanya terdapat di bagian header atau navigasi.

2.  **Isi Formulir Pendaftaran**
    Lengkapi semua kolom yang tersedia pada formulir pendaftaran dengan data diri Anda.

3.  **Cek Email Konfirmasi**
    Buka kotak masuk dari alamat email yang Anda daftarkan. Cari email konfirmasi dari Ragam Batik App.

4.  **Klik Link Konfirmasi**
    Di dalam email tersebut, Anda akan menemukan link dengan tulisan seperti **"Confirm your mail"**. Klik link tersebut untuk memverifikasi akun Anda.

5.  **Lakukan Sign In Kembali**
    Setelah akun terverifikasi, kembali ke halaman aplikasi dan lakukan **Sign In** menggunakan email dan password yang telah Anda daftarkan.

6.  **Berhasil**
    Anda sekarang berhasil login dan dapat menikmati seluruh fitur di Ragam Batik App.

## Catatan Penting

Terkadang, proses pengiriman email konfirmasi dapat memakan waktu lebih lama dari yang diharapkan. Jika Anda ingin mencoba aplikasi tanpa harus menunggu email konfirmasi, Anda dapat menggunakan akun yang sudah kami siapkan dan verifikasi di bawah ini:

  * **Email**: `ridelaproject@gmail.com`
  * **Password**: `12345678`

dengan menggunakan email tersebut, anda sudah bisa mulai menjelajah perjalanan mu!.

-----