
const CONFIG = {
    BASE_URL : 'https://zu1jx5klr3.execute-api.ap-southeast-2.amazonaws.com'
}
export default CONFIG;